let saveBtn = document.querySelector('.btn-save');
saveBtn.addEventListener('click',()=>{
  if(document.getElementById('options_engraving_text').value != ''){
    document.getElementById('engraving_text_selected').innerHTML = `"${document.getElementById('options_engraving_text').value}"`;
  }
  else{
    document.getElementById('engraving_text_selected').innerHTML = document.getElementById('options_engraving_text').value;

  }
    document.querySelector('.engraving-btn details').removeAttribute('open') 
  if(document.getElementById('engraving_text_selected').textContent != ''){
    document.querySelector('summary.engraving-btn-text').classList.add('link');
    document.querySelector('summary.engraving-btn-text').innerHTML = "Edit"
  } 
  else{
    document.querySelector('summary.engraving-btn-text').classList.remove('link');
    document.querySelector('summary.engraving-btn-text').innerHTML = "ADD ENGRAVING"

  }
})
if(document.getElementById('engraving_text_selected').textContent != ''){
    document.querySelector('summary.engraving-btn-text').innerHTML = "Edit"
} 
let closeBtn = document.querySelector('.btn-cancel');
closeBtn.addEventListener('click',()=>{
    document.querySelector('.engraving-btn details').removeAttribute('open') 
})


//----- Collection Tab in collection page

